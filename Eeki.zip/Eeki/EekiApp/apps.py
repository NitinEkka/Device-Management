from django.apps import AppConfig


class EekiappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'EekiApp'
