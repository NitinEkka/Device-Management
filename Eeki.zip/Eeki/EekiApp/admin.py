from django.contrib import admin
from .models import Config
from .models import Farm
from .models import Device
from .models import BasicTest
from .models import FunctionalTest
from .models import AssemblyTest
from .models import Shipping
from .models import Deployment
from .models import ChangeStatus

from django.shortcuts import render
from django.contrib import messages
from .form import *


# class StatusAdmin(admin.ModelAdmin):
#     model = Config
#     actions = ['basictestdone', 'functionaltestdone', 'assemblytestdone', 'shippingdone', 'deploymentdone', 'Alldone']
#     fields = ['pcbid', 'deviceid','basicteststatus','functionalteststatus', 'assemblyteststatus', 'shippingstatus', 'deploymentstatus', 'status',]

#     def basictestdone(self, request, queryset):
#         queryset.update(basicteststatus = True)

#     def functionaltestdone(self, request, queryset):
#         queryset.update(functionalteststatus = True)

#     def assemblytestdone(self, request, queryset):
#         queryset.update(assemblyteststatus = True)

#     def shippingdone(self, request, queryset):
#         queryset.update(shippingstatus = True)

#     def deploymentdone(self, request, queryset):
#         queryset.update(deploymentstatus = True)

#     def Alldone(self, request, queryset):
#         queryset.update(status = True)    




class DeviceAdmin(admin.ModelAdmin):
    list_display = ('pcbid', 'pcbboardversion', 'atmega', 'esp32', 'deviceid', 'status')
    actions = ['set_changestatus_action']
    

    def set_changestatus_action(self, request, queryset):
        if 'do_action' in request.POST:
            form = DeviceForm(request.POST)
            if form.is_valid():
                status = form.cleaned_data['status']
                updated = queryset.update(status=status)
                changefrom = form.cleaned_data['changefrom']
                updated1 = queryset.update(changefrom=changefrom)
                remarks = form.changed_data['remarks']
                updated2 = queryset.update(remarks=remarks)
                messages.success(request, '{0} status were updated'.format(updated2))
                messages.success(request, '{0} status were updated'.format(updated1))
                messages.success(request, '{0} status were updated'.format(updated))
                return
        else:
            form = DeviceForm()

        return render(request, 'index.html',
            {'title': u'Choose Status',
             'objects': queryset,
             'form': form})
    set_changestatus_action.short_description = u'Update status of selected device'



    # def set_status_action(self, request, queryset):
    #     if request.method == 'POST':
    #         status = request.POST.get('status')
    #         changefrom = request.POST.get('changefrom')
    #         remarks = request.POST.get('remarks')
    #         # dt = Form(status=status, changefrom=changefrom, remarks=remarks)
    #         # dt.save()
    #         queryset.update(Form(status=status, changefrom=changefrom, remarks=remarks))

    #     return render(request, 'Form_register_New.html')
        
        
        # if 'do_action' in request.POST:
        #     form = Form(request.POST)
        #     if form.is_valid():
        #         status = form.cleaned_data['status']
        #         updated = queryset.update(status=status)
        #         messages.success(request, '{0} status were updated'.format(updated))
        #         changefrom = form.changed_data['changefrom']
        #         updated1 = queryset.update(changefrom=changefrom)
        #         messages.success(request, '{0} changefrom were updated'.format(updated1))
        #         remarks = form.changed_data['remarks']
        #         updated2 = queryset.update(remarks=remarks)
        #         messages.success(request, '{0} remarks were updated'.format(updated2))
        #         return
        #     else:
        #         form = Form()    


        #     context = {
        #         'form' : form
        #     }    
        #     return render(request, 'index.html', context)
    # set_status_action.short_description = u'Update change status'        


admin.site.register(Device, DeviceAdmin)
admin.site.register(Config)
admin.site.register(Farm)
admin.site.register(ChangeStatus)
admin.site.register(BasicTest)
admin.site.register(FunctionalTest)
admin.site.register(AssemblyTest)
admin.site.register(Shipping)
admin.site.register(Deployment)
