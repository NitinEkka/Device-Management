from dataclasses import fields
from django import forms
from .models import ChangeStatus, Device
 

class Form(forms.ModelForm):
    
    class Meta:
        model = ChangeStatus
        fields = "__all__"

class DeviceForm(forms.ModelForm):

    class Meta:
        model = Device
        fields = "__all__"        